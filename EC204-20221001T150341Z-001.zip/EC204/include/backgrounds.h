#ifndef _backgrounds
#define _backgrounds
/********************************************************** 
 * backgrounds.h
 **********************************************************/

extern void display_back01();
extern void display_back02();

extern void init_video();
extern void init_background();

#endif