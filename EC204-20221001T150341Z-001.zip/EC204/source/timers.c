/**********************************************************
 * timers.c
 **********************************************************/

/* 
 * Añadir los includes que sean necesarios
 **/
#include <nds.h>
#include <stdio.h>
#include "defines.h"
#include "sprites.h"

/* 
 * Rutina de atención a la interrupción del temporizador
 **/
void timer_handler() {

	// De momento no hay nada

} // timer_handler()
